package com.bzl.football3d;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private final String[] teams = {"Neon City FC","Red Lions","Blue Waves","Royal Stars","North United","Golden Eagles","Metro Athletic","Thunder FC"};
    private String selectedTeam = "Neon City FC";

    @Override public void onCreate(Bundle b){super.onCreate(b); immersive(); selectedTeam=getPreferences(MODE_PRIVATE).getString("team",teams[0]); showMenu();}
    @Override public void onWindowFocusChanged(boolean h){super.onWindowFocusChanged(h);if(h)immersive();}
    private void immersive(){getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}

    private TextView title(String t,int sp){TextView v=new TextView(this);v.setText(t);v.setTextColor(Color.WHITE);v.setTextSize(sp);v.setGravity(Gravity.CENTER);v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);return v;}
    private GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);g.setStroke(2,Color.argb(60,255,255,255));return g;}
    private Button menuButton(String text){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(17);b.setAllCaps(false);b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);b.setBackground(bg(Color.rgb(15,35,51),24));b.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)v.animate().scaleX(.95f).scaleY(.95f).setDuration(80).start();if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(130).start();return false;});return b;}

    private void showMenu(){
        FrameLayout root=new FrameLayout(this);root.setBackground(bg(Color.rgb(4,13,22),0));
        LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.HORIZONTAL);all.setPadding(28,22,28,22);root.addView(all,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setGravity(Gravity.CENTER);hero.setPadding(20,10,30,10);all.addView(hero,new LinearLayout.LayoutParams(0,-1,1.15f));
        TextView badge=title("⚽",76);hero.addView(badge);
        TextView t=title("BZL FOOTBALL 3D",34);hero.addView(t);
        TextView sub=title("MOBILE FOOTBALL • 3D • OFFLINE",14);sub.setTextColor(Color.rgb(25,230,140));hero.addView(sub);
        TextView selected=title("YOUR CLUB  •  "+selectedTeam,16);selected.setPadding(0,22,0,0);hero.addView(selected);

        LinearLayout menu=new LinearLayout(this);menu.setOrientation(LinearLayout.VERTICAL);menu.setGravity(Gravity.CENTER);all.addView(menu,new LinearLayout.LayoutParams(0,-1,1f));
        String[] names={"⚡ Kick Off","🏆 Tournament","📈 Career Mode","🎯 Training","👕 Choose Team","⚙ Settings"};
        for(String n:names){Button b=menuButton(n);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,0,1);lp.setMargins(6,6,6,6);menu.addView(b,lp);
            if(n.contains("Kick")) b.setOnClickListener(v->startGame("kickoff"));
            else if(n.contains("Tournament")) b.setOnClickListener(v->startGame("tournament"));
            else if(n.contains("Career")) b.setOnClickListener(v->showCareer());
            else if(n.contains("Training")) b.setOnClickListener(v->startGame("training"));
            else if(n.contains("Choose")) b.setOnClickListener(v->chooseTeam());
            else b.setOnClickListener(v->settings());
        }
        setContentView(root);
    }

    private void startGame(String mode){Intent i=new Intent(this,GameActivity.class);i.putExtra("mode",mode);i.putExtra("team",selectedTeam);startActivity(i);}
    private void chooseTeam(){new AlertDialog.Builder(this).setTitle("Choose your club").setSingleChoiceItems(teams,indexOf(selectedTeam),(d,w)->{selectedTeam=teams[w];getPreferences(MODE_PRIVATE).edit().putString("team",selectedTeam).apply();d.dismiss();showMenu();}).setNegativeButton("Cancel",null).show();}
    private int indexOf(String s){for(int i=0;i<teams.length;i++)if(teams[i].equals(s))return i;return 0;}
    private void settings(){
        String[] opts={"Easy AI","Normal AI","Hard AI","3 minute matches","5 minute matches","Vibration ON/OFF"};
        new AlertDialog.Builder(this).setTitle("Game settings").setItems(opts,(d,w)->{android.content.SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);if(w<3)p.edit().putInt("difficulty",w).apply();else if(w==3)p.edit().putInt("minutes",3).apply();else if(w==4)p.edit().putInt("minutes",5).apply();else p.edit().putBoolean("vibration",!p.getBoolean("vibration",true)).apply();}).setPositiveButton("Done",null).show();
    }
    private void showCareer(){
        android.content.SharedPreferences p=getSharedPreferences("career",MODE_PRIVATE);int played=p.getInt("played",0),wins=p.getInt("wins",0),goals=p.getInt("goals",0),coins=p.getInt("coins",500);
        new AlertDialog.Builder(this).setTitle("Career • "+selectedTeam).setMessage("Season progress\n\nMatches: "+played+"\nWins: "+wins+"\nGoals: "+goals+"\nClub credits: "+coins+"\n\nWin matches to grow your club and earn credits.").setPositiveButton("Play next match",(d,w)->startGame("career")).setNegativeButton("Close",null).show();
    }
}
