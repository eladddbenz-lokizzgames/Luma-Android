package com.bzl.football3d;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class GameActivity extends Activity {
    private FootballRenderer renderer;
    private android.opengl.GLSurfaceView gl;

    @Override public void onCreate(Bundle b){super.onCreate(b); immersive();
        String mode=getIntent().getStringExtra("mode"); if(mode==null)mode="kickoff";
        String team=getIntent().getStringExtra("team"); if(team==null)team="Neon City FC";
        int difficulty=getSharedPreferences("settings",MODE_PRIVATE).getInt("difficulty",1);
        int minutes=getSharedPreferences("settings",MODE_PRIVATE).getInt("minutes",3);
        if(mode.equals("training")) minutes=10;
        final String finalMode=mode, finalTeam=team;

        FrameLayout root=new FrameLayout(this);
        gl=new android.opengl.GLSurfaceView(this);gl.setEGLContextClientVersion(2);
        renderer=new FootballRenderer(this,mode,team,difficulty,minutes,new FootballRenderer.GameListener(){
            @Override public void onMatchEnd(int us,int them,int goals){runOnUiThread(()->finishMatch(finalMode,finalTeam,us,them,goals));}
        });
        gl.setRenderer(renderer);gl.setRenderMode(android.opengl.GLSurfaceView.RENDERMODE_CONTINUOUSLY);root.addView(gl,new FrameLayout.LayoutParams(-1,-1));
        ControlsView controls=new ControlsView(this,renderer);root.addView(controls,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private void finishMatch(String mode,String team,int us,int them,int goals){
        if(mode.equals("career")){android.content.SharedPreferences p=getSharedPreferences("career",MODE_PRIVATE);p.edit().putInt("played",p.getInt("played",0)+1).putInt("wins",p.getInt("wins",0)+(us>them?1:0)).putInt("goals",p.getInt("goals",0)+goals).putInt("coins",p.getInt("coins",500)+75+us*20+(us>them?150:0)).apply();}
        String result=us>them?"VICTORY!":us<them?"FULL TIME":"DRAW";
        new AlertDialog.Builder(this).setCancelable(false).setTitle(result).setMessage(team+"  "+us+" - "+them+"  CPU\n\nGoals scored: "+goals+"\nMode: "+mode.toUpperCase()).setPositiveButton("Play again",(d,w)->recreate()).setNegativeButton("Main menu",(d,w)->finish()).show();
    }

    @Override protected void onPause(){super.onPause();if(gl!=null)gl.onPause();}
    @Override protected void onResume(){super.onResume();if(gl!=null)gl.onResume();immersive();}
    @Override public void onWindowFocusChanged(boolean h){super.onWindowFocusChanged(h);if(h)immersive();}
    private void immersive(){getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}

    static class ControlsView extends View {
        private final FootballRenderer r; private final Paint p=new Paint(3); private float joyX,joyY; private boolean joyActive; private float baseX,baseY; private int pointer=-1;
        ControlsView(Context c,FootballRenderer r){super(c);this.r=r;p.setTypeface(Typeface.DEFAULT_BOLD);setLayerType(View.LAYER_TYPE_SOFTWARE,null);postInvalidateOnAnimation();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();
            FootballRenderer.Status s=r.status();
            p.setColor(Color.argb(185,3,13,22));c.drawRoundRect(w*.36f,12,w*.64f,72,22,22,p);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(24);p.setColor(Color.WHITE);c.drawText(s.team+"  "+s.home+"  -  "+s.away+"  CPU",w/2f,39,p);p.setTextSize(15);p.setColor(Color.rgb(25,230,140));c.drawText(s.timeText,w/2f,62,p);
            // joystick
            float bx=joyActive?baseX:105, by=joyActive?baseY:h-105; p.setColor(Color.argb(65,255,255,255));c.drawCircle(bx,by,72,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.argb(160,255,255,255));c.drawCircle(bx,by,72,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(180,255,255,255));c.drawCircle(joyActive?joyX:bx,joyActive?joyY:by,30,p);
            drawBtn(c,w-92,h-92,56,"SHOOT",Color.rgb(255,70,76));drawBtn(c,w-205,h-75,50,"PASS",Color.rgb(39,171,255));drawBtn(c,w-92,h-205,47,"SPRINT",Color.rgb(25,230,140));drawBtn(c,w-48,48,28,"Ⅱ",Color.rgb(38,46,60));
            // mini map
            p.setColor(Color.argb(110,0,0,0));c.drawRoundRect(w/2f-75,h-92,w/2f+75,h-20,10,10,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.argb(160,255,255,255));c.drawRect(w/2f-68,h-86,w/2f+68,h-26,p);p.setStyle(Paint.Style.FILL);
            for(float[] q:s.miniHome){p.setColor(Color.CYAN);c.drawCircle(w/2f+q[0]*5.5f,h-56+q[1]*2.0f,3.5f,p);}for(float[] q:s.miniAway){p.setColor(Color.RED);c.drawCircle(w/2f+q[0]*5.5f,h-56+q[1]*2.0f,3.5f,p);}p.setColor(Color.WHITE);c.drawCircle(w/2f+s.ballX*5.5f,h-56+s.ballZ*2.0f,3,p);
            postInvalidateOnAnimation();
        }
        private void drawBtn(Canvas c,float x,float y,float rad,String text,int color){p.setColor(Color.argb(205,Color.red(color),Color.green(color),Color.blue(color)));p.setShadowLayer(12,0,5,Color.argb(100,0,0,0));c.drawCircle(x,y,rad,p);p.clearShadowLayer();p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(rad<30?20:12);c.drawText(text,x,y+5,p);}
        @Override public boolean onTouchEvent(MotionEvent e){int w=getWidth(),h=getHeight();int a=e.getActionMasked();int idx=e.getActionIndex();float x=e.getX(idx),y=e.getY(idx);
            if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_POINTER_DOWN){int id=e.getPointerId(idx);if(x<w*.45f&&y>h*.45f&&!joyActive){pointer=id;baseX=x;baseY=y;joyX=x;joyY=y;joyActive=true;updateJoy();}else if(dist(x,y,w-92,h-92)<70)r.shoot();else if(dist(x,y,w-205,h-75)<65)r.pass();else if(dist(x,y,w-92,h-205)<65)r.setSprint(true);else if(dist(x,y,w-48,48)<42)r.togglePause();return true;}
            if(a==MotionEvent.ACTION_MOVE&&joyActive){for(int i=0;i<e.getPointerCount();i++)if(e.getPointerId(i)==pointer){float dx=e.getX(i)-baseX,dy=e.getY(i)-baseY;float d=(float)Math.sqrt(dx*dx+dy*dy);if(d>72){dx*=72/d;dy*=72/d;}joyX=baseX+dx;joyY=baseY+dy;updateJoy();break;}return true;}
            if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_POINTER_UP||a==MotionEvent.ACTION_CANCEL){int id=e.getPointerId(idx);if(id==pointer){joyActive=false;pointer=-1;r.setMove(0,0);}r.setSprint(false);return true;}return true;}
        private void updateJoy(){r.setMove((joyX-baseX)/72f,-(joyY-baseY)/72f);}private float dist(float x,float y,float a,float b){float dx=x-a,dy=y-b;return(float)Math.sqrt(dx*dx+dy*dy);}
    }
}
