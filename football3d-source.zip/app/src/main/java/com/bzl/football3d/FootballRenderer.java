package com.bzl.football3d;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;

import java.nio.*;
import java.util.*;

public class FootballRenderer implements GLSurfaceView.Renderer {
    public interface GameListener { void onMatchEnd(int us,int them,int goals); }
    public static class Status {
        public int home,away; public String timeText,team; public float ballX,ballZ; public float[][] miniHome,miniAway;
    }
    private static class P { float x,z,vx,vz; float homeX,homeZ; boolean gk; P(float x,float z,boolean g){this.x=x;this.z=z;homeX=x;homeZ=z;gk=g;} }

    private final Context ctx; private final String mode,team; private final int difficulty,minutes; private final GameListener listener;
    private final P[] home=new P[7], away=new P[7];
    private float ballX=0,ballZ=0,ballVX=0,ballVZ=0,ballSpin=0; private float moveX,moveZ; private boolean sprint,paused,ended; private int selected=3;
    private int scoreHome=0,scoreAway=0,goalsByUser=0; private long startMs,lastMs,pauseStarted,totalPaused; private int program,aPos,uMvp,uColor; private FloatBuffer cubeBuf,lineBuf; private ShortBuffer cubeIdx; private int cubeCount;
    private final float[] proj=new float[16],view=new float[16],model=new float[16],mv=new float[16],mvp=new float[16];
    private final Random rng=new Random(); private long goalFreezeUntil=0;

    public FootballRenderer(Context c,String mode,String team,int difficulty,int minutes,GameListener l){this.ctx=c;this.mode=mode;this.team=team;this.difficulty=difficulty;this.minutes=minutes;this.listener=l;setupTeams();}
    private void setupTeams(){
        home[0]=new P(0,13.5f,true);home[1]=new P(-6,8,false);home[2]=new P(0,9,false);home[3]=new P(6,8,false);home[4]=new P(-4,2,false);home[5]=new P(4,2,false);home[6]=new P(0,-3,false);
        away[0]=new P(0,-13.5f,true);away[1]=new P(-6,-8,false);away[2]=new P(0,-9,false);away[3]=new P(6,-8,false);away[4]=new P(-4,-2,false);away[5]=new P(4,-2,false);away[6]=new P(0,3,false);
    }

    public synchronized void setMove(float x,float z){moveX=x;moveZ=z;} public synchronized void setSprint(boolean s){sprint=s;}
    public synchronized void togglePause(){paused=!paused;if(paused)pauseStarted=SystemClock.uptimeMillis();else totalPaused+=SystemClock.uptimeMillis()-pauseStarted;}
    public synchronized void pass(){ if(paused||ended)return; P p=home[selected]; if(dist(p.x,p.z,ballX,ballZ)<2.4f){int best=-1;float bd=999;for(int i=1;i<home.length;i++){if(i==selected)continue;float d=dist(p.x,p.z,home[i].x,home[i].z);if(home[i].z<p.z+3&&d<bd){bd=d;best=i;}}if(best<0)best=(selected+1)%home.length;float dx=home[best].x-ballX,dz=home[best].z-ballZ,n=(float)Math.sqrt(dx*dx+dz*dz)+.001f;ballVX=dx/n*9.5f;ballVZ=dz/n*9.5f;}}
    public synchronized void shoot(){if(paused||ended)return;P p=home[selected];if(dist(p.x,p.z,ballX,ballZ)<2.7f){float tx=(rng.nextFloat()-.5f)*2.6f;float dx=tx-ballX,dz=-15.5f-ballZ,n=(float)Math.sqrt(dx*dx+dz*dz)+.001f;ballVX=dx/n*15.5f;ballVZ=dz/n*15.5f;}}

    public synchronized Status status(){Status s=new Status();s.home=scoreHome;s.away=scoreAway;s.team=team;s.ballX=ballX;s.ballZ=ballZ;long rem=Math.max(0,minutes*60000L-elapsed());s.timeText=paused?"PAUSED":String.format(Locale.US,"%02d:%02d",rem/60000,(rem/1000)%60);s.miniHome=new float[home.length][2];s.miniAway=new float[away.length][2];for(int i=0;i<home.length;i++){s.miniHome[i][0]=home[i].x;s.miniHome[i][1]=home[i].z;s.miniAway[i][0]=away[i].x;s.miniAway[i][1]=away[i].z;}return s;}
    private long elapsed(){if(startMs==0)return 0;long now=SystemClock.uptimeMillis();return now-startMs-totalPaused-(paused?now-pauseStarted:0);}

    @Override public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl,javax.microedition.khronos.egl.EGLConfig cfg){
        GLES20.glClearColor(.025f,.055f,.075f,1);GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glEnable(GLES20.GL_BLEND);GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA);
        String vs="uniform mat4 uMVP; attribute vec3 aPos; void main(){gl_Position=uMVP*vec4(aPos,1.0);}";
        String fs="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}";
        program=link(vs,fs);aPos=GLES20.glGetAttribLocation(program,"aPos");uMvp=GLES20.glGetUniformLocation(program,"uMVP");uColor=GLES20.glGetUniformLocation(program,"uColor");makeCube();makeLines();startMs=lastMs=SystemClock.uptimeMillis();
    }
    @Override public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,48f,w/(float)Math.max(1,h),.3f,100f);}
    @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl){long now=SystemClock.uptimeMillis();float dt=Math.min(.035f,(now-lastMs)/1000f);lastMs=now;if(!paused&&!ended)update(dt,now);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);drawScene(now);if(!ended&&!mode.equals("training")&&elapsed()>=minutes*60000L){ended=true;if(listener!=null)listener.onMatchEnd(scoreHome,scoreAway,goalsByUser);}}

    private void update(float dt,long now){if(now<goalFreezeUntil)return;chooseSelected();P me=home[selected];float speed=sprint?7.2f:5.0f;me.vx=moveX*speed;me.vz=-moveZ*speed; // controls: up joystick -> negative z
        me.x=clamp(me.x+me.vx*dt,-9.2f,9.2f);me.z=clamp(me.z+me.vz*dt,-14.2f,14.2f);
        float aiSpeed=3.4f+difficulty*.8f;
        // teammates retain formation but support ball
        for(int i=0;i<home.length;i++){if(i==selected)continue;P p=home[i];float tx=p.homeX*.75f+ballX*.25f,tz=p.homeZ*.75f+ballZ*.18f;if(p.gk){tx=clamp(ballX*.45f,-2.5f,2.5f);tz=13.6f;}moveToward(p,tx,tz,p.gk?3.2f:3.7f,dt);}
        // away nearest outfield chases ball, GK guards goal
        int ch=1;float best=999;for(int i=1;i<away.length;i++){float d=dist(away[i].x,away[i].z,ballX,ballZ);if(d<best){best=d;ch=i;}}
        for(int i=0;i<away.length;i++){P p=away[i];float tx,tz,sp=aiSpeed;if(p.gk){tx=clamp(ballX*.5f,-2.7f,2.7f);tz=-13.6f;sp=4f;}else if(i==ch){tx=ballX;tz=ballZ;}else{tx=p.homeX*.7f+ballX*.3f;tz=p.homeZ*.78f+ballZ*.16f;}moveToward(p,tx,tz,sp,dt);}
        // player-ball interaction: dribble
        for(P p:home){float d=dist(p.x,p.z,ballX,ballZ);if(d<1.05f){float dx=ballX-p.x,dz=ballZ-p.z,n=(float)Math.sqrt(dx*dx+dz*dz);if(n<.1f){dx=0;dz=-1;n=1;}float kick=p==me?2.3f:1.3f;ballVX+=dx/n*kick;ballVZ+=dz/n*kick;}}
        for(P p:away){float d=dist(p.x,p.z,ballX,ballZ);if(d<1.0f){float dx=ballX-p.x,dz=ballZ-p.z,n=(float)Math.sqrt(dx*dx+dz*dz)+.001f;ballVX+=dx/n*2f;ballVZ+=dz/n*2f;if(!p.gk&&rng.nextFloat()<.045f*(difficulty+1)){float gx=-ballX*.05f;float gz=15.5f-ballZ,n2=(float)Math.sqrt(gx*gx+gz*gz)+.001f;ballVX=gx/n2*11f;ballVZ=gz/n2*11f;}}}
        ballX+=ballVX*dt;ballZ+=ballVZ*dt;float friction=(float)Math.pow(.985,dt*60);ballVX*=friction;ballVZ*=friction;ballSpin+=Math.sqrt(ballVX*ballVX+ballVZ*ballVZ)*dt*70;
        // side walls
        if(ballX<-9.9f){ballX=-9.9f;ballVX=Math.abs(ballVX)*.65f;}if(ballX>9.9f){ballX=9.9f;ballVX=-Math.abs(ballVX)*.65f;}
        if(ballZ<-15.25f){if(Math.abs(ballX)<3.35f){scoreHome++;goalsByUser++;goal(now);}else{ballZ=-15.1f;ballVZ=Math.abs(ballVZ)*.55f;}}
        if(ballZ>15.25f){if(Math.abs(ballX)<3.35f){scoreAway++;goal(now);}else{ballZ=15.1f;ballVZ=-Math.abs(ballVZ)*.55f;}}
    }
    private void chooseSelected(){int b=1;float d=999;for(int i=1;i<home.length;i++){float q=dist(home[i].x,home[i].z,ballX,ballZ);if(q<d){d=q;b=i;}}if(dist(home[selected].x,home[selected].z,ballX,ballZ)>4.8f)selected=b;}
    private void goal(long now){goalFreezeUntil=now+1000;ballX=ballZ=ballVX=ballVZ=0;for(P p:home){p.x=p.homeX;p.z=p.homeZ;}for(P p:away){p.x=p.homeX;p.z=p.homeZ;}}
    private void moveToward(P p,float tx,float tz,float sp,float dt){float dx=tx-p.x,dz=tz-p.z,n=(float)Math.sqrt(dx*dx+dz*dz);if(n>.15f){p.x+=dx/n*sp*dt;p.z+=dz/n*sp*dt;}p.x=clamp(p.x,-9.2f,9.2f);p.z=clamp(p.z,-14.2f,14.2f);}

    private void drawScene(long now){P focus=home[selected];float camX=focus.x*.22f+ballX*.08f,camZ=focus.z+22f;camZ=Math.max(11f,camZ);Matrix.setLookAtM(view,0,camX,17.5f,camZ,focus.x*.15f,0,focus.z-3.8f,0,1,0);GLES20.glUseProgram(program);
        // stadium + pitch
        box(0,-.2f,0,10.2f,.18f,15.35f,.045f,.36f,.13f,1);box(0,-.35f,-18.2f,14,1.7f,2.3f,.07f,.11f,.16f,1);box(0,-.35f,18.2f,14,1.7f,2.3f,.07f,.11f,.16f,1);box(-13,-.35f,0,2.2f,1.7f,16,.06f,.10f,.15f,1);box(13,-.35f,0,2.2f,1.7f,16,.06f,.10f,.15f,1);
        drawPitchLines();drawGoal(-15.15f);drawGoal(15.15f);
        // player shadows + players
        for(int i=0;i<home.length;i++){P p=home[i];box(p.x,.03f,p.z,.45f,.025f,.45f,0,0,0,.22f);player(p.x,p.z,i==selected?.1f:.02f,.7f,1f,p.gk?1.15f:1f);}
        for(P p:away){box(p.x,.03f,p.z,.45f,.025f,.45f,0,0,0,.22f);player(p.x,p.z,1f,.16f,.12f,p.gk?1.15f:1f);}
        // selected marker
        ringMarker(focus.x,focus.z,now);
        // ball
        box(ballX,.36f,ballZ,.25f,.25f,.25f,.96f,.96f,.98f,1);
    }
    private void player(float x,float z,float r,float g,float b,float scale){box(x,.72f,z,.38f,.68f,.32f,r,g,b,1);box(x,1.55f,z,.27f,.27f,.27f,.82f,.64f,.48f,1);box(x-.18f,.17f,z,.11f,.48f,.13f,.08f,.10f,.14f,1);box(x+.18f,.17f,z,.11f,.48f,.13f,.08f,.10f,.14f,1);}
    private void ringMarker(float x,float z,long now){float s=.62f+(float)Math.sin(now/120.0)*.08f;box(x,.04f,z,s,.018f,s,.1f,1f,.8f,.42f);}
    private void drawGoal(float z){float c=.93f;box(-3.2f,1.1f,z,.08f,1.15f,.08f,c,c,c,1);box(3.2f,1.1f,z,.08f,1.15f,.08f,c,c,c,1);box(0,2.18f,z,3.28f,.07f,.08f,c,c,c,1);box(-3.2f,.9f,z+(z<0?-.85f:.85f),.05f,.9f,.85f,c,c,c,.45f);box(3.2f,.9f,z+(z<0?-.85f:.85f),.05f,.9f,.85f,c,c,c,.45f);}
    private void drawPitchLines(){float y=.015f;line(-10,y,-15,10,y,-15);line(-10,y,15,10,y,15);line(-10,y,-15,-10,y,15);line(10,y,-15,10,y,15);line(-10,y,0,10,y,0); // center
        int n=32;for(int i=0;i<n;i++){double a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n;line((float)Math.cos(a)*2.2f,y,(float)Math.sin(a)*2.2f,(float)Math.cos(b)*2.2f,y,(float)Math.sin(b)*2.2f);} // boxes
        line(-5,y,-15,-5,y,-10.5f);line(5,y,-15,5,y,-10.5f);line(-5,y,-10.5f,5,y,-10.5f);line(-5,y,15,-5,y,10.5f);line(5,y,15,5,y,10.5f);line(-5,y,10.5f,5,y,10.5f);
    }

    private void box(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,float a){Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.scaleM(model,0,sx,sy,sz);Matrix.multiplyMM(mv,0,view,0,model,0);Matrix.multiplyMM(mvp,0,proj,0,mv,0);GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES20.glUniform4f(uColor,r,g,b,a);GLES20.glEnableVertexAttribArray(aPos);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,0,cubeBuf);GLES20.glDrawElements(GLES20.GL_TRIANGLES,cubeCount,GLES20.GL_UNSIGNED_SHORT,cubeIdx);}
    private void line(float x1,float y1,float z1,float x2,float y2,float z2){float[] v={x1,y1,z1,x2,y2,z2};lineBuf.clear();lineBuf.put(v).position(0);Matrix.setIdentityM(model,0);Matrix.multiplyMM(mv,0,view,0,model,0);Matrix.multiplyMM(mvp,0,proj,0,mv,0);GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES20.glUniform4f(uColor,.95f,.95f,.95f,.9f);GLES20.glLineWidth(2);GLES20.glEnableVertexAttribArray(aPos);GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,0,lineBuf);GLES20.glDrawArrays(GLES20.GL_LINES,0,2);}
    private void makeCube(){float[] v={-1,-1,-1, 1,-1,-1, 1,1,-1,-1,1,-1,-1,-1,1,1,-1,1,1,1,1,-1,1,1};short[] idx={0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,1,5,6,1,6,2,0,3,7,0,7,4};cubeBuf=ByteBuffer.allocateDirect(v.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();cubeBuf.put(v).position(0);cubeIdx=ByteBuffer.allocateDirect(idx.length*2).order(ByteOrder.nativeOrder()).asShortBuffer();cubeIdx.put(idx).position(0);cubeCount=idx.length;}
    private void makeLines(){lineBuf=ByteBuffer.allocateDirect(6*4).order(ByteOrder.nativeOrder()).asFloatBuffer();}
    private int link(String vs,String fs){int v=GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);GLES20.glShaderSource(v,vs);GLES20.glCompileShader(v);int f=GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);GLES20.glShaderSource(f,fs);GLES20.glCompileShader(f);int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,v);GLES20.glAttachShader(p,f);GLES20.glLinkProgram(p);return p;}
    private float dist(float x,float z,float a,float b){float dx=x-a,dz=z-b;return(float)Math.sqrt(dx*dx+dz*dz);}private float clamp(float v,float a,float b){return Math.max(a,Math.min(b,v));}
}
